"""wrf_domain_tool 初始化模块"""

__version__ = "0.1.0"
